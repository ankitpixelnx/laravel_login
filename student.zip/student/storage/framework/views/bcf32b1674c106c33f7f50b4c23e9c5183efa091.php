<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Custome Auth</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4"style="margin-top:20px;">
         <h4>Login</h4>
        <hr>
        <form action="<?php echo e(route('login-user')); ?>"method="post">
        <?php if(Session::has('success')): ?> 
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('fail')): ?> 
        <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>    
        <?php echo csrf_field(); ?>
         
           <div class="form-group">
            <label for="email">Email</label>
            <input type="text"class="form-control" placeholder="Enter email"name="email"value="<?php echo e(old('email')); ?>">
            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
           </div> 
           <div class="form-group">
            <label for="password">Password</label>
            <input type="text"class="form-control" placeholder="Enter password"name="password"value="<?php echo e(old('password')); ?>">
            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
           </div> 
           <div class="form-group">
            <button class="btn btn-block btn-primary"type="submit">login</button>
           </div>
           <br>
           <a href="registration">New User !! Registration here</a>


        </form>

        </div>



    </div>

</div>

    
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html><?php /**PATH C:\xampps\htdocs\student\resources\views/auth/login.blade.php ENDPATH**/ ?>